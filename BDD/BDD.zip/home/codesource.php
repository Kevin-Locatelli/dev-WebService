Example :<br />
<?php
echo "Current date : ";
echo date("l F d, Y");
?>